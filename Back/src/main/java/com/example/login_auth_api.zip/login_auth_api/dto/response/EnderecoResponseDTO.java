package com.example.login_auth_api.dto.response;

public class EnderecoResponseDTO {
}
